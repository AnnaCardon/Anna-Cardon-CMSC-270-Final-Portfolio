#ifndef BITSPOP_H_
#define BITSPOP_H_

#include "BitsOrganism.h"

class BitsPop {

    std::vector<BitsOrganism *> pop; //vector holding the population
    int popsize;

public:

    BitsPop(int n, int genomesize) {
        popsize = n;
        for (int i = 0; i < n; i++) {
            BitsOrganism* org = new BitsOrganism(genomesize);
            pop.push_back(org);
        }
    }

    void update(const std::vector<BitsOrganism*> & newpop) {
        pop = newpop;
    }

    std::vector<BitsOrganism*> getPop() {
        return pop;
    }

    BitsOrganism* getMax() {
        auto it = std::max_element(pop.begin(), pop.end());
        return *it;
    }

    std::vector<BitsOrganism*> tournament_select(int tournsize) {
        std:: vector<BitsOrganism*> newpop; //created a vector for new pop
        newpop.reserve(popsize); //assign size of the vector to be the same as og pop

        for (int i = 1; i<popsize; i++){ //loop to go through vector
            std::vector<BitsOrganism*> tournament; //made a tournament vector
            tournament.reserve(tournsize); //saved size

            for (int x=0; x<tournsize; x++){ //loop goes through our pop vector and returns random organisms into tournament vector
                tournament.push_back(pop[rand()%popsize]);
            }

            auto rank = std::max_element(tournament.begin(), tournament.end()); //rank the organisms chosen by fitness
            newpop.push_back(*rank); //in our new pop put in the organisms selected by order rank
        }
        return newpop;
    }

    std::vector<BitsOrganism*> roulette_select() {
        /* your implementation
        int new_pop;
        std::vector<int>cum; //cumulative fitness
        double cNum = 0;
        double totalF = 0; // total fittness
        double prop = 0;
        while (new_pop < popsize) {
            //popsize = rand();
            for (int i = 0; i < popsize; i++){ //calculate cumulative fitness
 		        totalF += pop[i]->getScore(); //assign and add the pop score in var totalF
 		            if (i = 0){
                        cNum = pop[i]->getScore(); //assign the score to cNum and put into cum vector at index
                        cum[i] = cNum; //put the value of cNum into the inedx of cum vector
                    }else{
                        cNum = cum[i-1] + pop[i]->getScore(); //add past score to new one coming in
                        cum[i]= cNum; //put into cumulative vector
                    }
                
 	            }

        }*/
    }

};

#endif /*BITSPOP_H_*/