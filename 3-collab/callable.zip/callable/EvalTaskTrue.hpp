#ifndef MABE_EVAL_TASK_TRUE_H
#define MABE_EVAL_TASK_TRUE_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise EQU operation
  class EvalTaskTrue : public EvalTaskBase<EvalTaskTrue, 2> {

  public:
    EvalTaskTrue(mabe::MABE & control,
                  const std::string & name="EvalTaskTrue",
                  const std::string & desc="Evaluate organism on true logic task")
      : EvalTaskBase(control, name, "equ", desc){;}

    ~EvalTaskTrue() { }
    
    /// Check if the passed output is equal to input_a EQU input_b  
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return output == true;
    }
  };

  MABE_REGISTER_MODULE(EvalTaskTrue, "Organism-triggered evaluation of true operation");

}

#endif