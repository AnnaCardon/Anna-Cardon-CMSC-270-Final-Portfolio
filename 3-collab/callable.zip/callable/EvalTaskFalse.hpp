#ifndef MABE_EVAL_TASK_FALSE_H
#define MABE_EVAL_TASK_FALSE_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise EQU operation
  class EvalTaskFalse : public EvalTaskBase<EvalTaskFalse, 2> {

  public:
    EvalTaskFalse(mabe::MABE & control,
                  const std::string & name="EvalTaskFalse",
                  const std::string & desc="Evaluate organism on true logic task")
      : EvalTaskBase(control, name, "false", desc){;}

    ~EvalTaskFalse() { }
    
    /// Check if the passed output is equal to input_a EQU input_b  
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return output == false;
    }
  };

  MABE_REGISTER_MODULE(EvalTaskFalse, "Organism-triggered evaluation of False operation");

}

#endif