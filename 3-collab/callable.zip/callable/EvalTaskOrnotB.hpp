/**
 *  @note This file is part of MABE, https://github.com/mercere99/MABE2
 *  @copyright Copyright (C) Michigan State University, MIT Software license; see doc/LICENSE.md
 *  @date 2021-2022.
 *
 *  @file  EvalTaskOrnot.h
 *  @brief Tests organism output for bitwise ORNOT operation
 *
 *  A ORNOT B is equal to A OR (~B), where ~ is bitwise NOT.
 *  Here, however, we check both directions. So we also look for B OR (~A).
 */

#ifndef MABE_EVAL_TASK_ORNOTB_H
#define MABE_EVAL_TASK_ORNOTB_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise ORNOT operation
  class EvalTaskOrnotB : public EvalTaskBase<EvalTaskOrnotB, 2> {

  public:
    EvalTaskOrnotB(mabe::MABE & control,
                  const std::string & name="EvalTaskOrnotB",
                  const std::string & desc="Evaluate organism on ORNOTB logic task")
      : EvalTaskBase(control, name, "ornotB", desc){;}

    ~EvalTaskOrnotB() { }

    
    /// Check if the passed output is equal to input_a ORNOT input_b or input_b ORNOT input_a
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return (output == (input_a | ~input_b));
    }
  };

  MABE_REGISTER_MODULE(EvalTaskOrnotB, "Organism-triggered evaluation of ORNOTB operation");

}

#endif
