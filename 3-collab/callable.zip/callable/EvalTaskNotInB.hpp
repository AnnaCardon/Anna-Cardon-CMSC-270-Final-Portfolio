#ifndef MABE_EVAL_TASK_NOTInB_H
#define MABE_EVAL_TASK_NOTInB_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise NOT operation
  class EvalTaskNotInB : public EvalTaskBase<EvalTaskNotInB, 1> {
  public:
    EvalTaskNotInB(mabe::MABE & control,
                  const std::string & name="EvalTaskNotInB",
                  const std::string & desc="Evaluate organism on NOTInB logic task")
      : EvalTaskBase(control, name, "notInB", desc){;}

    /// Check if the passed output is bitwise NOT of the passed input  
    bool CheckOneArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return output == ~input_b;
    }
  };
    
  MABE_REGISTER_MODULE(EvalTaskNotInB, "Organism-triggered evaluation of NOTInB operation");

}

#endif