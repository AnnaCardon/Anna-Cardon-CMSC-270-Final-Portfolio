#ifndef MABE_EVAL_TASK_NOTA_H
#define MABE_EVAL_TASK_NOTA_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise ANDNOT operation
  class EvalTaskNotA : public EvalTaskBase<EvalTaskNotA, 2> {

  public:
    EvalTaskNotA(mabe::MABE & control,
                  const std::string & name="EvalTaskNotA",
                  const std::string & desc="Evaluate organism on NOTA logic task")
      : EvalTaskBase(control, name, "notA", desc){;}

    ~EvalTaskNotA() { }

    /// Check if passed output is equal to input_a ANDNOT input_b or input_b ANDNOT input_a 
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return (output == (input_b & ~input_a));
    }
  };

  MABE_REGISTER_MODULE(EvalTaskNotA, "Organism-triggered evaluation of NOTA operation");

}

#endif