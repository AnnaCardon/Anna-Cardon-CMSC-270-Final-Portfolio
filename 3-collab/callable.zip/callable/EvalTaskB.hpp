#ifndef MABE_EVAL_TASK_B_H
#define MABE_EVAL_TASK_B_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise ANDNOT operation
  class EvalTaskB : public EvalTaskBase<EvalTaskB, 2> {

  public:
    EvalTaskB(mabe::MABE & control,
                  const std::string & name="EvalTaskB",
                  const std::string & desc="Evaluate organism on B logic task")
      : EvalTaskBase(control, name, "b", desc){;}

    ~EvalTaskB() { }

    /// Check if passed output is equal to input_a ANDNOT input_b or input_b ANDNOT input_a 
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return output == input_b;
    }
  };

  MABE_REGISTER_MODULE(EvalTaskAndnot, "Organism-triggered evaluation of ANDNOT operation");

}

#endif