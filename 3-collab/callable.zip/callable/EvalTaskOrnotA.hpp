#ifndef MABE_EVAL_TASK_ORNOTA_H
#define MABE_EVAL_TASK_ORNOTA_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise ORNOT operation
  class EvalTaskOrnotA : public EvalTaskBase<EvalTaskOrnotA, 2> {

  public:
    EvalTaskOrnotA(mabe::MABE & control,
                  const std::string & name="EvalTaskOrnotA",
                  const std::string & desc="Evaluate organism on ORNOTA logic task")
      : EvalTaskBase(control, name, "ornotA", desc){;}

    ~EvalTaskOrnotA() { }

    
    /// Check if the passed output is equal to input_a ORNOT input_b or input_b ORNOT input_a
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return (output == (input_b | ~input_a));
    }
  };

  MABE_REGISTER_MODULE(EvalTaskOrnotA, "Organism-triggered evaluation of ORNOTA operation");

}

#endif